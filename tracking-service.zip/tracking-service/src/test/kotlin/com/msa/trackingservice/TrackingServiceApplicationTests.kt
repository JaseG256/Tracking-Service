package com.msa.trackingservice

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class TrackingServiceApplicationTests {

	@Test
	fun contextLoads() {
	}

}
